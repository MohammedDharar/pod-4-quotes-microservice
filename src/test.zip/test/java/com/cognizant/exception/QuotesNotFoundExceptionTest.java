package com.cognizant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Test - QuotesNotFoundException class
 */
@SpringBootTest
class QuotesNotFoundExceptionTest {

	@Test
	void testQuotesNotFoundException() {
		QuotesNotFoundException quotesNotFoundException = new QuotesNotFoundException(
				"Quotes Not Found");
		assertEquals("Quotes Not Found", quotesNotFoundException.getMessage());
	}

}
