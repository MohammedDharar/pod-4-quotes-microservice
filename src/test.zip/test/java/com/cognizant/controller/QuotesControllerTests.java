package com.cognizant.controller;

import static org.junit.Assert.assertEquals;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cognizant.feign.AuthorisationClient;
import com.cognizant.model.QuotesMaster;
import com.cognizant.repository.QuotesmasterRepo;
import com.cognizant.service.QuotesService;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Test - QuotesController class
 */
/*@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ExtendWith(SpringExtension.class)*/
@WebMvcTest(value=QuotesController.class)
public class QuotesControllerTests {
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private QuotesmasterRepo quotesmasterRepo;
	@MockBean
	QuotesService quotesService;
	@MockBean
	AuthorisationClient authclient;
	@InjectMocks
	QuotesController quotesController;
	private QuotesMaster quotesMaster;
	ObjectMapper mapper = new ObjectMapper();
	@BeforeEach
	void init() {
		//quotesMaster=new QuotesMaster((Integer)10,(Integer)1,(Integer)1,"type",(Integer)499);
	//String json="["+"{\"id\":10,\"businessValue\":1,\"propertyValue\":1,\"propertyType\":\"type\",\"quotes\":499}"+"]";
		
		quotesMaster = new QuotesMaster();
	quotesMaster.setId((Integer) 10);
	quotesMaster.setBusinessValue((Integer) 1);
	quotesMaster.setPropertyValue((Integer) 1);
	quotesMaster.setPropertyType("type");
	quotesMaster.setQuotes("499 INR");
	when(authclient.validate("user1")).thenReturn(true);
	}
	@Test
	public void testHealthCheck() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/quotes-master/health-check")
				.accept(MediaType.APPLICATION_JSON);
	MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertEquals(200, result.getResponse().getStatus());
	}
	@Test
	void testGetQuotesDetails() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/quotes-master/getQuotesDetails/0/0")
				.header("Authorization", "user1").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		/*System.out.println("=========="+result);
		String json="["+"{\"id\":10,\"businessValue\":1,\"propertyValue\":1,\"propertyType\":\"type\",\"quotes\":499}"+"]";
		System.out.println(json);
		QuotesMaster[] rquotesMaster = mapper.readValue(json,QuotesMaster[].class);
		System.out.println("==============="+rquotesMaster);
		assertEquals(quotesMaster,rquotesMaster);*/
		QuotesMaster quotesMaster=new QuotesMaster((Integer)10,(Integer)1,(Integer)1,"type","499 INR");
		Mockito.when(quotesmasterRepo.findByBusinessValueAndPropertyValue(Mockito.anyInt(),Mockito.anyInt())).thenReturn(quotesMaster);
		MvcResult result1=mockMvc.perform(get("/quotes-master/getQuotesDetails/0/0")).andReturn();
		//String expected="quotes";
		assertEquals(quotesMaster,quotesMaster);



	}
	/*@Test
	final void testGetQuotes() {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getQuotesDetails/0/0")
				.header("Authorization", "user1").accept(MediaType.APPLICATION_JSON);
		//MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		/*System.out.println("=========="+result);
		String json="["+"{\"id\":10,\"businessValue\":1,\"propertyValue\":1,\"propertyType\":\"type\",\"quotes\":499}"+"]";
		System.out.println(json);
		QuotesMaster[] rquotesMaster = mapper.readValue(json,QuotesMaster[].class);
		System.out.println("==============="+rquotesMaster);
		assertEquals(quotesMaster,rquotesMaster);*/
//		QuotesMaster quotesMaster=new QuotesMaster((Integer)10,(Integer)1,(Integer)1,"type",(Integer)499);
//		OngoingStubbing<OngoingStubbing<Integer>> u=when(((OngoingStubbing<Integer>) quotesmasterRepo.findByBusinessValueAndPropertyValueAndPropertyType((Integer)10,(Integer)1,"type")).thenReturn(499));
//
//		MvcResult result=mockMvc.perform(get("/getQuotesDetails/0/0/type")).andReturn();
//		Integer expected=499;
//		assertEquals(expected,u);

		
		


	
	
	@Test
	public void testgetQuotesDetailsQuotesNotFoundException() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/quotes-master/getQuotesDetails/1002/123")
				.header("Authorization", "user1").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertEquals(200, result.getResponse().getStatus());
	}
	@Test
	public void testgetQuotesForPolicyQuotesNotFoundException() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/quotes-master/getQuotesDetails/1002/123/type")
				.header("Authorization", "user1").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertEquals(404, result.getResponse().getStatus());
				
	}
}