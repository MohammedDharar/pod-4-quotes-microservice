package com.cognizant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class QuotesMasterTest {
	
	QuotesMaster quotesMaster = new QuotesMaster((Integer)1, (Integer)2, (Integer)2, "factory", "399 INR");

	@Test
	public void testPropertyType() {
		quotesMaster.setPropertyType("factory");
		assertEquals("factory", quotesMaster.getPropertyType());
	}

	@Test
	public void testQuotes() {
		quotesMaster.setQuotes("399 INR");
		assertEquals("399 INR", quotesMaster.getQuotes());
	}
}
