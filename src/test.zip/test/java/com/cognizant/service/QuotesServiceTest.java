package com.cognizant.service;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.model.QuotesMaster;
import com.cognizant.repository.QuotesmasterRepo;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class QuotesServiceTest {
	@Mock
	private QuotesmasterRepo quotesmasterRepo;
	@InjectMocks
	private QuotesService quotesService;
	QuotesMaster quotesMaster;

	@BeforeEach
	void init() {
		quotesMaster = new QuotesMaster((Integer) 1, (Integer) 2, (Integer) 2, "factory", "499 INR");

	}

	@Test
	void getQuotesMasterTest() {
		Mockito.when(quotesmasterRepo.findByBusinessValueAndPropertyValueAndPropertyType((Integer) 2, (Integer) 2,"factory"))
				.thenReturn(new QuotesMaster((Integer) 1, (Integer) 2, (Integer) 2, "factory", "499 INR"));
		assertEquals(quotesMaster, quotesMaster);
	}

	@Test
	void getQuotesTest() {
		Mockito.when(quotesmasterRepo.findByBusinessValueAndPropertyValue((Integer) 2, (Integer) 2))
				.thenReturn(new QuotesMaster((Integer) 1, (Integer) 2, (Integer) 2, "factory", "499 INR"));
		assertEquals(quotesMaster, quotesMaster);

	}
}
